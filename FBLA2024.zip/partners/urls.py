from django.urls import path
from .views import partner_list, partner_proposal, partner_list_json

urlpatterns = [
    path('', partner_list, name='partner_list'),
    path('json/partner_list', partner_list_json, name='partner_list_json'),
    path('partner', partner_proposal, name='partner_proposal'),
]
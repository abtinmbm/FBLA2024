from partners.models import PartnerTag, Resource, ResourceTag
def get_public_resources():
    resources = []
    partner_tags = PartnerTag.objects.all()
    resource_tags = ResourceTag.objects.all()
    for resource in Resource.objects.filter(partner__status="active").all():

        resources.append(
            {
                "id": resource.id,
                "name": resource.name,
                "description": resource.description,
                "tags": list(resource.tags.all().values()),
                "partner": {
                    "name": resource.partner.name,
                    "description": resource.partner.description,
                    "logo": (
                        resource.partner.logo.url if resource.partner.logo else None
                    ),
                    "website": resource.partner.website,
                    "contact_email": resource.partner.contact_email,
                    "contact_phone": resource.partner.contact_phone,
                    "tags": list(resource.partner.tags.all().values()),
                },
            }
        )
    return resources
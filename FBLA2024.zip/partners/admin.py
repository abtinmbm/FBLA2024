from typing import Any
from django.contrib import admin
from django.http.request import HttpRequest
from django.contrib.auth.models import User, Group
from .forms import PartnerStaffForm
from .models import (
    PartnerTag,
    ResourceTag,
    PartnerProfile,
    PartnerStaff,
    Resource,
)


class PartnerTagAdmin(admin.ModelAdmin):
    list_display = ("name", "description")


admin.site.register(PartnerTag, PartnerTagAdmin)


class ResourceTagAdmin(admin.ModelAdmin):
    list_display = ("name", "description")


admin.site.register(ResourceTag, ResourceTagAdmin)


class PartnerStaffAdmin(admin.ModelAdmin):
    list_display = ("user", "partner", "role")

    def get_form(self, request: HttpRequest, obj: Any = None, **kwargs: Any) -> Any:
        if not request.user.is_superuser and obj is None:
            kwargs["form"] = PartnerStaffForm
        return super().get_form(request, obj, **kwargs)

    def get_exclude(self, request, obj=None):
        if request.user.is_superuser:
            return ()
        else:
            return ("partner", "user")

    def get_readonly_fields(self, request: HttpRequest, obj):
        if request.user.is_superuser:
            return super().get_readonly_fields(request, obj)
        else:
            if obj and obj.user and obj.user == request.user:
                return ["role"]
            else:
                return super().get_readonly_fields(request, obj)

    def has_delete_permission(self, request: HttpRequest, obj=None):
        if request.user.is_superuser:
            return
        else:
            if obj and obj.user and obj.user == request.user:
                return False
            else:
                return True

    def delete_model(self, request: HttpRequest, obj: Any) -> None:
        if request.user.is_superuser:
            return super().delete_model(request, obj)
        else:
            obj.user.delete()

    def save_model(self, request, obj, form, change):
        if "username" in form.cleaned_data:
            partner_staffs = PartnerStaff.objects.filter(user=request.user).first()
            obj.partner_id = partner_staffs.partner.id
            current_user = User.objects.filter(
                username__iexact=form.cleaned_data["username"],
                email__iexact=form.cleaned_data["email"],
            ).first()
            obj.user = User.objects.create_user(
                username=form.cleaned_data["username"],
                email=form.cleaned_data["email"],
                password=form.cleaned_data["password"],
                is_staff=True,
            )
            if form.cleaned_data["role"] == "manager":
                group = Group.objects.get(name="Partner Staff - Manager")
            else:
                group = Group.objects.get(name="Partner Staff - Editor")
            obj.user.groups.add(group)
            obj.save()
        else:
            super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if not request.user.is_superuser:
            partner_staffs = PartnerStaff.objects.filter(user=request.user).first()
            if partner_staffs is None:
                return qs.none()
            qs = qs.filter(partner=partner_staffs.partner)
        return qs


admin.site.register(PartnerStaff, PartnerStaffAdmin)


class PartnerProfileAdmin(admin.ModelAdmin):
    list_display = ("name", "status", "tag_list")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if not request.user.is_superuser:
            partner_staffs = PartnerStaff.objects.filter(user=request.user).first()
            if partner_staffs is None:
                return qs.none()
            qs = qs.filter(id=partner_staffs.partner.id)
        return qs

    def tag_list(self, obj):
        return ", \n ".join([p.name for p in obj.tags.all()])

    def get_readonly_fields(self, request, obj=None):
        if not request.user.is_superuser:
            return ["status"]
        else:
            return []


admin.site.register(PartnerProfile, PartnerProfileAdmin)


class ResourceAdmin(admin.ModelAdmin):
    list_display = ("name", "tag_list", "partner")

    def tag_list(self, obj):
        return ", \n ".join([p.name for p in obj.tags.all()])

    def get_exclude(self, request, obj):
        if not request.user.is_superuser:
            return ["partner"]
        else:
            return []

    def save_model(self, request, obj, form, change):
        if not obj.partner_id:
            partner_staffs = PartnerStaff.objects.filter(user=request.user).first()
            if partner_staffs is None:
                return
            obj.partner_id = partner_staffs.partner.id
        obj.save()

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if not request.user.is_superuser:
            partner_staffs = PartnerStaff.objects.filter(user=request.user).first()
            if partner_staffs is None:
                return qs.none()
            qs = qs.filter(partner=partner_staffs.partner)

        return qs


admin.site.register(Resource, ResourceAdmin)

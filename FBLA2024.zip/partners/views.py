import json
from django.shortcuts import render, redirect
from .models import PartnerProfile, PartnerStaff, PartnerTag, Resource, ResourceTag
from .forms import PartnerForm
from django.contrib.auth.models import User, Group
from django.contrib.auth import login
from django.shortcuts import render
from django.db import IntegrityError, transaction
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import PartnerProfile
from django.http import JsonResponse
from .functions import get_public_resources

def partner_list(request):
    resources = get_public_resources()
    partner_tags = PartnerTag.objects.all()
    resource_tags = ResourceTag.objects.all()
    return render(
        request,
        "partner_list.html",
        {
            "resources": resources,
            "resources_json": json.dumps(resources),
            "partner_tags": partner_tags,
            "resource_tags": resource_tags,
        },
    )


def partner_list_json(request):
    resources = get_public_resources()
    return JsonResponse({"data": resources})


def partner_proposal(request):
    if request.method == "POST":
        form = PartnerForm(request.POST, request.FILES)
        if form.is_valid():
            if User.objects.filter(
                username__iexact=form.cleaned_data["username"]
            ).exists():
                form.add_error("username", "Username or email already exists")
                return render(request, "partner_proposal.html", {"form": form})
            if User.objects.filter(email__iexact=form.cleaned_data["email"]).exists():
                form.add_error("email", "Username or email already exists")
                return render(request, "partner_proposal.html", {"form": form})
            try:
                with transaction.atomic():
                    profile = PartnerProfile.objects.create(
                        name=form.cleaned_data["name"],
                        description=form.cleaned_data["description"],
                        logo=form.cleaned_data["logo"],
                        website=form.cleaned_data["website"],
                        contact_email=form.cleaned_data["contact_email"],
                        contact_phone=form.cleaned_data["contact_phone"],
                    )
                    user = User.objects.create_user(
                        username=form.cleaned_data["username"],
                        email=form.cleaned_data["email"],
                        password=form.cleaned_data["password"],
                        is_staff=True,
                    )
                    profile.tags.set(form.cleaned_data["tags"])
                    user.groups.add(Group.objects.get(id=1))
                    PartnerStaff.objects.create(user=user, partner=profile, role="manager")
                    login(request, user)
                    return HttpResponseRedirect("/admin")
            except IntegrityError:
                form.add_error(
                    None, "Something went wrong. Please try again or contact support."
                )
                return render(request, "partner_proposal.html", {"form": form})

    # if a GET (or any other method) we'll create a blank form
    else:
        form = PartnerForm()

    return render(request, "partner_proposal.html", {"form": form})

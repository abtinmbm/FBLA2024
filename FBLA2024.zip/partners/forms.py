from django import forms
from .models import PartnerTag
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django_recaptcha.fields import ReCaptchaField

class PartnerForm(forms.Form):
    name = forms.CharField(label="Name")
    description = forms.CharField(label="Description")
    logo = forms.ImageField(label="Logo", required=False)
    website = forms.URLField(label="Website", initial="https://")
    contact_email = forms.EmailField(label="Contact Email")
    contact_phone = forms.CharField(label="Contact Phone", required=False)
    tags = forms.ModelMultipleChoiceField(
        queryset=PartnerTag.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        label="Tags",
    )
    email = forms.EmailField(label="Email")
    username = forms.CharField(label="Username")
    password = forms.CharField(
        label="Password", widget=forms.PasswordInput(), validators=[validate_password]
    )
    captcha = ReCaptchaField()

class PartnerStaffForm(forms.ModelForm):
    role = forms.ChoiceField(
        choices=(
            ("manager", "Manager"),
            ("editor", "Editor"),
        ),
        label="Role",
    )
    email = forms.EmailField(label="Email", required=True)
    username = forms.CharField(label="Username")
    password = forms.CharField(
        label="Password", widget=forms.PasswordInput(), validators=[validate_password]
    )
    def clean(self):
        cleaned_data = super().clean()
        if "username" in cleaned_data and "email" in cleaned_data:
            current_user = User.objects.filter(
            username__iexact=cleaned_data["username"],
            email__iexact=cleaned_data["email"],
            ).first()
            curent_email = User.objects.filter(
            email__iexact=cleaned_data["email"],
            ).first()
            curent_username = User.objects.filter(
            username__iexact=cleaned_data["username"],
            ).first()
            if curent_email:
                self.add_error("email", "Email already exists")
            if curent_username:
                self.add_error("username", "Username already exists")
            return cleaned_data
